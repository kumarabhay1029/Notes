# BCA_SEM-2_notes
BCA Second Semester Notes from academic book!
